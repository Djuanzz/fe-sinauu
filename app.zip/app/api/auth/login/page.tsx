import SignIn from "@/components/auth/login";

export default function LoginPage() {
  return <SignIn />;
}
