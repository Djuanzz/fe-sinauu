import SocialAuth from "@/components/auth/socialAuth";

export default function SocialAuthPage() {
  return <SocialAuth />;
}
